# NBA Scout v2.0 — Video-Informed Grading Upgrade (CANDIDATE)

Created 2026-11-07. Standalone, working scoring module + tests + v1.5 integration references. **NOT DEPLOYED TO LIVE NBA SCOUT v1.9.**

## Apply to the existing v1.9 app — do NOT overwrite its UI/source with old v1.5 code
1. Keep the current v1.9 repository, current Top 10 MORE/LESS, line-feed adapters, RotoWire XLSX import, all matchups and frontend.
2. Add `lib/grading-v2.mjs` from this patch (an ESM module with no packages/dependencies).
3. Locate v1.9's existing prop evaluator (it may not be the same as the included **v1.5-only reference**). After the existing code has resolved the true player, game, exact provider line, historical results and any uploaded RotoWire row, call `gradePropV2` as shown below.
4. Keep the current 20 Nov 7 frozen v1.9 picks in the historical audit. Record `scoringVersion='2.0-hypothesis'` only for future comparison; never silently replace frozen historical grades.
5. Show `score`, `confidence`, `state`, `components`, `warnings`, `hard`, `missing`, `projectionSource` and `methodology` separately on expandable prop cards. Do NOT label `score` or `confidence` as win probability.
6. Run regression tests on the **current v1.9 source** before pushing. Once merged, verify `/api/health`, real RotoWire upload, Top 10 MORE/LESS, sorting, and a complete NBA slate. Deploy only from connected GitHub repository that actually serves `https://nba-shotzone-scout.onrender.com/`.

## Mapping from the existing v1.9 data to the v2 scoring API

```js
import {gradePropV2} from './lib/grading-v2.mjs';
const rating = gradePropV2({
  prop: {
    player: candidate.player,
    stat: candidate.statCode,  // PTS, REB, AST, 3PM, PRA, PA, PR, RA, FGA, 3PA, FTM
    line: candidate.standardLine,
    observedAt: candidate.lineObservedAt
  },
  side: candidate.side, // MORE or LESS
  hist: pregameHistory,  // must contain boxscoreGames, projectedBaseline,
                         // opportunity.minutesL5/minutesL10,
                         // recent (newest first: stat/minutes/fga/fta/tpa/pts/reb/ast),
                         // hitRates.last10 {win,push,loss}
  zone: currentShotZoneGradeOrNull, // {score} — only scoring/3PM stat influence
  independent: rotoWireRow ? {
    source: 'RotoWire user-uploaded projections; 2026-11-07',
    minutes: rotoWireRow.minutes,
    stat: rotoWireRow.projectionForExactPropStat,
    roleVerified: Boolean(confirmedStarterFromIndependentSameDaySource),
    injuryVerified: Boolean(injuryReportWasIndependentlyCheckedToday),
    statusObservedAt: verifiedInjuryTimestamp, // ISO timestamp
    injuryStatus: verifiedInjuryStatus // e.g. 'available' or 'out'
  } : null,
  consensusProjections: [], // only actual sourced alternative stat projections
  dvp: null, // or {score: ...,source:'FantasyPros [date] PG assists', verified:true}
  tracking: null, // or actual verified NBA tracking opportunities: source/verified,
                  // potentialAssists vs baselinePotentialAssists,
                  // reboundChances vs baselineReboundChances etc.
  environment: null, // or {score,source,verified:true} oriented to selected side
  market: null // or {lineVerified:true,offeredSideVerified:true,priceVerified:true,observedAt}
});
```

**All `...Verified` flags mean actual independently confirmed information, not inferred from the score.** A RotoWire uploaded minutes/projection row does NOT verify starting lineups, injury availability or PrizePicks offered sides by itself. A DvP position/stat rating must be defined for that stat; team-wide opponent shot zones don't substantiate REB/AST props.

## Weights (hypothesis to be backtested, not an empirically optimized system)

| Dimension | Points | Rationale |
|---|---:|---|
| Expected minutes and role | 30% | Minutes, injuries and actual rotation are upstream of nearly all props. |
| Independent projection gap vs exact line | 25% | RotoWire projection/expected stat must align with the selected side and account for variance. |
| Stat-specific opportunity | 20% | FGA, FTA, 3PA, potential assists, rebound chances, per-36 rates; combo props require multiple components. |
| Position/stat DvP + matching shot zones | 10% | Confirmations, not reasons to ignore role or volume. |
| Recent/season rates | 10% | Sample-size-shrunk true wins with pushes excluded; no raw L5 hit-rate probabilities. |
| Game environment | 5% | Pace, totals, blowout, rest, team competition; never fabricate. |

Missing fields contribute only neutral 50, are listed in `missing`, reduce `confidence`, and can cap the score. **The `score` is not P(win), a market edge or an authorization to bet.**

## Gates in code
- Exact standard line, time observed (over 6h = PASS; over 2h = downgrade).
- At least five historical usable games, low-minute veto; hard pass on unavailable player.
- Unverified role, injury or minutes -> score capped at 63 and never final.
- Strong sourced projection disagreement with the selected side -> score capped at 52.
- Large discrepancy between independent projections -> warning, not averaged away.
- Fragile extremely low standalone LESS lines -> hard veto.
- NBA tracking unavailable -> marked missing, not fabricated.
- Recent clear rate shrinkage toward neutral; pushes kept separate; combostat component-direction check.
- No unverified price/payout EV or implied hit probability.

## Videos and research methods captured from the user's previous work
- Guy Boston Sports / Evan Singleton: matchup-first, exact stat-by-position defensive weakness, role/volume, line and price. https://youtu.be/FrHS_3V7mt4
- TWO6ZERO: shot charts, play types, rebound chances, potential assists, minutes. https://youtu.be/ZxVrh-HV49M
- Cheese Picks: exact line, recent trends/H2H, complementary stats and sportsbook context. https://youtu.be/H43RBhkEwOA
- Final Round Sports: full-slate matchup analysis, defensive weaknesses, back-to-backs, spread/blowout, waiting for lineups. https://youtu.be/Jh2Hhw1CwYE
- Other user-shared daily picks videos provide hypotheses/examples but are **not** used to tune prediction weights based on selective claims of wins.

## Validation policy
Maintain both v1.9 and v2.0 candidate scores and re-grade **the exact frozen pregame prop/line/side** with official NBA final stats. Compare W/L/PUSH/DNP, full-slate control boards and accuracy by grade bucket, not only top 10. Require multiple slates and held-out comparison before promoting v2.0 weights. Do not treat one good night as proof. Historical snapshots are frozen outside ephemeral Render disk in ChatGPT Library folder `/NBA Scout Daily Snapshots/`.

## Included files
- `lib/grading-v2.mjs` — standalone new scoring module with optional RotoWire, DvP, tracking and market evidence
- `test/grading-v2.test.mjs` — 10 focused regression/edge-case tests (verified as passing on Node 22)
- `reference/props-v15-integration-example.mjs` — a working illustration adapted to **v1.5 only**, **NOT** a replacement for the existing v1.9 module
- `reference/clean-v15-display-example.js` — example UI rendering the breakdown, **NOT** a v1.9 replacement

## Verified state at packaging
The reference v1.5 package with the module integrated passed **36/36** tests. Live v1.9 deployed repository was not visible through the connected GitHub tool; no direct commit or Render deploy has been made.
