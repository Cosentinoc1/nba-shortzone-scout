'use strict';
const KEYS=['rim','paint','mid','left','right','above'];
const LABELS={rim:'Restricted area',paint:'Paint (non-RA)',mid:'Mid-range',left:'Left corner 3',right:'Right corner 3',above:'Above-break 3'};
const $=id=>document.getElementById(id);
const safe=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const fmt=n=>Number.isFinite(+n)?Number(n).toLocaleString():'—';
const pct=n=>Number.isFinite(n)?(n*100).toFixed(1)+'%':'—';
const signed=n=>Number.isFinite(n)?(n>0?'+':'')+n.toFixed(1)+'pp':'—';
const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9]/g,'').toLowerCase();
let selectedDate=null,selectedGameId=null,selectedGameDirection='away',slateRequestSerial=0;
let db=null,rankScope='today',lastGrade=null,requestSerial=0,currentLookup=null,lookupTicker=null;
async function api(url,options){const r=await fetch(url,{cache:'no-store',...options});let body=await r.json();if(!r.ok)throw new Error(body.error||body.reason||'Request failed');return body}
const prop=(p,k)=>(p?.zones?.[k]||{fga:0,fgm:0});
const total=p=>KEYS.reduce((v,k)=>v+(+prop(p,k).fga||0),0);
function rosterItem(){return (db?.rosters?.[$('offense').value]||[]).find(x=>String(x.id)===$('player').value)}
function profileLocal(){let r=rosterItem();if(!r)return null;return db.players.find(p=>p.team===$('offense').value&&normalize(p.name)===normalize(r.name))||null}
function defenseTeam(){return db?.defense?.teams?.find(x=>x.code===$('team').value)}
function league(){return db?.defense?.league}
function choices(select,arr,previous){select.replaceChildren();for(const [value,label] of arr){const o=document.createElement('option');o.value=value;o.textContent=label;select.appendChild(o)}if(previous&&arr.some(x=>x[0]===previous))select.value=previous}
function fillTeams(){const list=[...db.defense.teams].sort((a,b)=>a.name.localeCompare(b.name)).map(t=>[t.code,t.name]);choices($('team'),list,$('team').value||'CHA');choices($('offense'),list,$('offense').value||'BOS');choices($('compare'),[['','None'],...list],$('compare').value)}
function fillPlayers(preferredId){let arr=(db.rosters[$('offense').value]||[]).slice().sort((a,b)=>a.name.localeCompare(b.name));choices($('player'),arr.map(p=>[String(p.id),p.name+(p.pos?' · '+p.pos:'')]),preferredId||$('player').value);if(!arr.length)$('player').innerHTML='<option value="">Roster not available</option>'}
function showCoverage(){let s=db.status,source=s.source||'Saved snapshot';$('coverage').textContent=`${s.rosterProfiles??s.playerProfiles}/${s.rosterPlayers} players with profiles (${s.profileCoveragePct??'?'}%) · 30 rosters`; $('dataAsOf').textContent=`${source} · as of ${s.dataAsOf}`; $('playerLookupBadge').textContent='Server connected';$('syncHealth').textContent=s.refresh?.active?'Syncing':'Server online';}
function shortDayLabel(day){
 try{return new Date(day+'T12:00:00Z').toLocaleDateString('en-US',{timeZone:'UTC',weekday:'long',month:'long',day:'numeric',year:'numeric'})}catch{return day}
}
function gameClock(g){
 if(g.completed)return 'Final';
 if(g.state==='in')return g.statusText||'Live';
 if(!g.tipoff)return 'Tipoff TBD';
 try{return new Intl.DateTimeFormat('en-US',{hour:'numeric',minute:'2-digit',timeZone:'America/Chicago'}).format(new Date(g.tipoff))+' CT'}catch{return 'Tipoff TBD'}
}
function gameScores(g){
 if(g.state!=='post'&&g.state!=='in')return 'AT';
 if(g.awayScore==null||g.homeScore==null)return 'AT';
 return safe(g.awayScore)+' – '+safe(g.homeScore);
}
function favoredRosterId(team){
 const roster=db.rosters[team]||[];
 // Favor a real shooter with verified season attempts over an alphabetical bench player.
 const sorted=[...db.players].filter(p=>p.team===team&&p.gp>=2).sort((a,b)=>total(b)-total(a));
 for(const p of sorted){const r=roster.find(r=>normalize(r.name)===normalize(p.name));if(r&&total(p)>0)return String(r.id)}
 return roster[0]?String(roster[0].id):null;
}
function loadGame(g,direction='away'){
 if(!db||!g||!db.rosters[g.away]||!db.rosters[g.home])return;
 const offense=direction==='home'?g.home:g.away,defense=direction==='home'?g.away:g.home;
 selectedGameId=g.id;selectedGameDirection=direction;
 $('offense').value=offense;$('team').value=defense;
 fillPlayers(favoredRosterId(offense));renderToday();selectChanged();
 $('selectedGameHint').innerHTML=`<b>${safe(g.away)} @ ${safe(g.home)}</b> · Analyzing <b>${safe(offense)} shooters</b> vs <b>${safe(defense)} defense</b>. Choose a different player below to see their individual grade.`;
 $('matchupControls').scrollIntoView({behavior:'smooth',block:'start'});
}
function renderToday(){
 const host=$('todayGames');host.replaceChildren();
 $('dailyTitle').textContent=(selectedDate===db?.status?.date?"Today's Games":'NBA Games')+' · '+shortDayLabel(selectedDate);
 $('gameDate').value=selectedDate;
 const games=db.schedule||[];
 $('gameCount').textContent=games.length?`${games.length} game${games.length===1?'':'s'} · choose any matchup`:'No NBA games listed for this date';
 if(!games.length){host.innerHTML='<div class="slate-empty">No scheduled NBA games were returned for this date. Select another day above.</div>';return}
 for(const g of games){
  const card=document.createElement('article');card.className='slate-game'+(g.id===selectedGameId?' selected':'');card.setAttribute('role','listitem');
  const clock=gameClock(g),status=g.state==='in'?'Live':g.completed?'Final':'Scheduled';
  card.innerHTML=`<div class="game-statusline"><span class="game-status ${g.state==='in'?'live':''}">${safe(status)}</span><span>${safe(clock)}</span></div>
   <div class="game-versus"><div class="game-team"><span class="game-team-code">${safe(g.away)}</span><span class="game-team-role">AWAY</span></div>
    <div class="game-versus-center">${gameScores(g)}</div>
    <div class="game-team"><span class="game-team-code">${safe(g.home)}</span><span class="game-team-role">HOME</span></div></div>
   <div class="game-choices"><button type="button" class="game-pick ${g.id===selectedGameId&&selectedGameDirection==='away'?'active':''}" data-side="away">Analyze ${safe(g.away)}</button><button type="button" class="game-pick ${g.id===selectedGameId&&selectedGameDirection==='home'?'active':''}" data-side="home">Analyze ${safe(g.home)}</button></div>`;
  card.querySelector('[data-side="away"]').addEventListener('click',()=>loadGame(g,'away'));
  card.querySelector('[data-side="home"]').addEventListener('click',()=>loadGame(g,'home'));
  // One tap on a card loads the away offense against the home defense.
  card.addEventListener('click',e=>{if(!e.target.closest('button'))loadGame(g,'away')});
  host.appendChild(card);
 }
}
async function changeDay(day,force=false){
 if(!day||day<'2026-10-20'||day>'2027-04-11')return;
 selectedDate=day;selectedGameId=null;
 db.schedule=[];
 $('selectedGameHint').textContent='Select a game to load its matchup.';
 $('gameCount').textContent='Loading games for '+shortDayLabel(day)+'…';
 $('todayGames').innerHTML='<div class="slate-empty">Loading NBA schedule…</div>';
 $('gameDate').value=day;
 await loadSchedule(force);
}
function moveSlateDay(amount){
 const d=new Date((selectedDate||db.status.date)+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+amount);
 const next=d.toISOString().slice(0,10);changeDay(next);
}
function zoneHeat(def,z,mode,p){const x=def.zones[z],b=league().zones[z];let delta=mode==='fg'?(x.fg-b.fg):x.share-b.share;if(mode==='matchup'&&p){let share=prop(p,z).fga/Math.max(1,total(p));delta=(.68*(x.share-b.share)/.055+.32*(x.fg-b.fg)/.07)*Math.min(1,share/.18)*.11}let t=Math.min(1,Math.abs(delta)/(mode==='fg'?.11:.09));let s=delta>=0?[217,74,98]:[43,142,166];let n=[69,103,127].map((v,i)=>Math.round(v+(s[i]-v)*t));return `rgb(${n.join(',')})`}
function renderCourt(p,grade){let d=defenseTeam();if(!d)return;const m=$('measure').value,t=total(p);
 $('courtTitle').textContent=m==='matchup'?(p?`${p.name} vs ${d.name}`:`${d.name} · awaiting shooter`):`${d.name} · opponent ${m==='fg'?'FG%':'shot frequency'}`;
 $('snapshot').textContent=`Defense: ${db.status.source} · ${db.status.dataAsOf}`;
 for(let k of KEYS){$('zone-'+k).setAttribute('fill',zoneHeat(d,k,m,p));let dz=d.zones[k],pz=prop(p,k),pl=document.querySelector(`.plate[data-key="${k}"]`);
   let line1=LABELS[k],line2=m==='fg'?pct(dz.fg):pct(dz.share);
   if(m==='matchup'&&p){line2=`${pz.fga} FGA · ${pct(pz.fga/t)}`}
   pl.innerHTML=`<b>${safe(line1)}</b><em>${safe(line2)}</em><small>#${dz.rank_share??'—'}</small><i>${m==='matchup'?`Opp. ${pct(dz.share)} · ${pct(dz.fg)} FG`:`${m==='fg'?'Allowed FG%':'Attempts share'} · #${dz.rank_share??'—'} rank`}</i>`;
 }
 $('detailTitle').textContent=p?`${p.name} × ${d.name}`:`${d.name} defensive profile`;
 $('playerFga').textContent=p?fmt(t):'—';$('playerRate').textContent=p?.gp? (t/p.gp).toFixed(1):'—';$('defFga').textContent=fmt(d.attempts||KEYS.reduce((n,k)=>n+(d.zones[k].fga||0),0));
 $('topZone').textContent=p?LABELS[[...KEYS].sort((a,b)=>prop(p,b).fga-prop(p,a).fga)[0]]:'—';
 $('zoneCompare').innerHTML=KEYS.map(k=>{const q=prop(p,k),z=d.zones[k];return `<tr><td>${LABELS[k]}</td><td>${p?fmt(q.fga):'—'}</td><td>${p&&q.fga?pct(q.fgm/q.fga):'—'}</td><td>${pct(z.share)}</td><td>${pct(z.fg)}</td><td>#${z.rank_share??'—'}</td></tr>`}).join('');
 if(grade?.rows?.length){let best=[...grade.rows].sort((a,b)=>b.contribution-a.contribution)[0],worst=[...grade.rows].sort((a,b)=>a.contribution-b.contribution)[0];$('matchupReading').innerHTML=`<p><b>Best overlap:</b> ${safe(best.name)} — the defense allows ${signed(best.shareDeltaPP)} extra shot-share points relative to the league and ${signed(best.fgDeltaPP)} opponent FG% points.</p><p><b>Most restrictive overlap:</b> ${safe(worst.name)} (${signed(worst.shareDeltaPP)} shot share; ${signed(worst.fgDeltaPP)} FG%).</p>`;}
 else $('matchupReading').textContent='No eligible shooter profile yet. Defensive zones are shown, but no player matchup inference is available.';
 $('qualityNote').textContent=p?`Player source: ${p.source||'NBA saved snapshot'} (${p.asof||db.status.dataAsOf}). Defense source: ${db.status.source}. ${p.gp?`Player games: ${p.gp}.`:'Games played unknown.'} ESPN reconstructed coordinates and official NBA zones may differ.`:'No confirmed player six-zone profile. Nothing will be assigned a matchup grade without measured attempts.';
}
function signalLabel(n){if(n>=.2)return 'Favorable';if(n<=-.2)return 'Restrictive';return 'Near neutral'}
function renderGrade(g,p){lastGrade=g;if(!g?.score){$('gradeNumber').textContent='—';$('gradeLetter').textContent=g?.reason||'Not graded';$('gradeStatus').textContent='Insufficient data';$('gradePlayerLabel').textContent=p?.name||'Choose a player';$('gradeConfidence').textContent='Requires actual shooting attempts';$('gradeDrivers').textContent='No matchup grade without a measured shot-zone profile.';$('gradeZoneDetail').textContent='Six-zone profile unavailable.';return}
 $('gradeNumber').textContent=g.score.toFixed(1);$('gradeNumber').style.color=g.score>=58?'#36d6a3':g.score<46?'#fc8d98':'#e8cc80';$('gradeLetter').textContent=`${g.grade} · ${g.score>=58?'Favorable alignment':g.score<46?'Restrictive alignment':'Mixed matchup'}`;
 $('gradeStatus').textContent=g.eligible?'Eligible for rankings':'Provisional grade';$('gradePlayerLabel').textContent=`${p.name} • ${p.team} • ${g.total} FGA in ${g.gp||'?'} games`; $('gradeConfidence').textContent=`Data confidence: ${g.confidence}`;
 for(const [id,bar,val] of [['gradeVolume','volumeTrack',g.volumeSignal],['gradeAccuracy','accuracyTrack',g.efficiencySignal]]){$(id).textContent=`${val>0?'+':''}${val.toFixed(2)} · ${signalLabel(val)}`;$(bar).style.width=(50+val*45)+'%';$(bar).style.background=val>=0?'#3ad8a6':'#ef7d89'}
 $('gradeDrivers').innerHTML=g.drivers.map(x=>`${x.contribution>=0?'▲':'▼'} <b>${safe(x.name)}</b> · ${x.playerFga} FGA (${pct(x.playerShare)} of player's shots), defense ${signed(x.shareDeltaPP)} share / ${signed(x.fgDeltaPP)} FG%.`).join('<div style="margin:6px 0"></div>');
 $('gradeZoneDetail').innerHTML='<div class="grade-zone-row header"><span>ZONE</span><span>PLAYER FGA</span><span>DEF RANK</span><span>FG% GAP</span></div>'+g.rows.map(r=>`<div class="grade-zone-row"><span>${safe(r.name)}</span><span>${r.playerFga}</span><span>#${r.defRank??'—'}</span><span style="color:${r.fgDeltaPP>=0?'#70ddb4':'#ffa6af'}">${signed(r.fgDeltaPP)}</span></div>`).join('');
 $('gradeCaveat').textContent=`Scoring formula: ${g.method} ${g.eligible?'Meets minimum FGA and games sample.':'PROVISIONAL: fewer than four games or 40 shots, so excluded from Top/Worst 6 rankings.'} This does not account for expected minutes, opponent defenders or today's market lines.`;
}
function renderBoard(){let d=db.defense;let columns='<th>Team</th>'+KEYS.map(k=>`<th>${safe(LABELS[k])}<br><small>share • rank</small></th>`).join('');$('columns').innerHTML=columns;
 let by=[...d.teams].sort((a,b)=>a.name.localeCompare(b.name));$('board').innerHTML=by.map(t=>`<tr data-code="${t.code}"><td>${safe(t.name)}</td>${KEYS.map(k=>`<td>${pct(t.zones[k].share)} <span class="bubble">#${t.zones[k].rank_share||'—'}</span></td>`).join('')}</tr>`).join('');
 for(let tr of $('board').querySelectorAll('tr[data-code]'))tr.addEventListener('click',()=>{$('team').value=tr.dataset.code;if($('team').value===$('offense').value){$('offense').value=[...d.teams].find(t=>t.code!==tr.dataset.code).code;fillPlayers()}selectChanged();window.scrollTo({top:0,behavior:'smooth'})});
}
function renderComparison(){let c=$('compare').value;if(!c){$('compareBox').innerHTML='';return}let a=defenseTeam(),b=db.defense.teams.find(t=>t.code===c);$('compareBox').innerHTML=`<strong>${a.name} versus ${b.name}</strong><p class="small">${KEYS.map(z=>`${LABELS[z]}: ${pct(a.zones[z].share)} vs ${pct(b.zones[z].share)}`).join(' · ')}</p>`}
function renderRankItem(r,i){const node=document.createElement('button');node.type='button';node.className='rank-item';node.innerHTML=`<span class="rank-index">${i+1}.</span><span class="rank-main"><b>${safe(r.player)}</b><small>${safe(r.offense)} vs ${safe(r.defense)} · ${safe(r.position)}</small><small>${LABELS[r.topZone]||''} · ${r.attempts} FGA / ${r.games} GP</small></span><span class="rank-score" style="color:${r.score>=58?'#55dfb3':r.score<45?'#ff94a0':'#e5d495'}">${r.score.toFixed(1)}</span>`;
 node.onclick=()=>{if(!db.rosters[r.offense])return;$('team').value=r.defense;$('offense').value=r.offense;let roster=db.rosters[r.offense].find(x=>normalize(x.name)===normalize(r.player));fillPlayers(roster?.id);selectChanged();window.scrollTo({top:0,behavior:'smooth'})};return node;}
async function rankings(){if(!db)return;const section=$('rankCoverage');try{
 const out=await api('/api/rankings?scope='+rankScope+'&date='+encodeURIComponent(selectedDate||db.status.date));
 const total=Number(out.totalRosterSlots)||0,graded=Number(out.eligiblePlayers)||0,measured=Number(out.availableProfiles)||0;
 const low=Number(out.notQualified)||0,missing=Number(out.missingProfiles)||0;
 $('auditEligible').textContent=fmt(graded);$('auditLowSample').textContent=fmt(low);
 $('auditMissing').textContent=fmt(missing);$('auditTotal').textContent=fmt(total);
 $('rankCoverageFill').style.width=total?(100*graded/total).toFixed(1)+'%':'0%';
 const datasetComplete=missing===0,ready=graded>=6;
 $('rankAuditTitle').textContent=total?
  `${graded} / ${total} roster entries grade-eligible (${out.coveragePct}%) · ${measured} with measured profiles`:
  'No usable matchup schedule / roster entries for this ranking scope';
 section.textContent=`${rankScope==='today'?shortDayLabel(selectedDate)+' games':'All hypothetical opponent pairings'} · ${out.pairings} team-vs-defense comparisons · stats through ${out.asof} · ${out.source}.`;
 $('rankAuditWarning').textContent=!total?'No verified games available. Nothing is ranked.':
  `${missing} players lack measured shot-zone profiles; ${low} have profiles but fail the four-game/40-FGA minimum. ${datasetComplete?'All roster entries have profiles, but not all are eligible.':'This is NOT a complete-slate ranking.'} No injury/starting-role verification is included.`;
 $('topSixTitle').textContent=`Top ${Math.min(6,graded)} among ${graded} eligible`;
 $('worstSixTitle').textContent=`Worst ${Math.min(6,graded)} among ${graded} eligible`;
 for(const [name,items] of [['topSix',out.top],['worstSix',out.worst]]){
  const h=$(name);h.replaceChildren();
  if(!items.length){h.innerHTML=`<div class="empty-board">No qualified comparisons available. ${rankScope==='today'?'We need a verified current slate and player shot-zone profiles.':'Missing players are never counted as unfavorable.'}</div>`;}
  else items.forEach((x,i)=>h.appendChild(renderRankItem(x,i)));
 }
 }catch(e){section.textContent=`Could not calculate rankings: ${e.message}`;$('rankAuditWarning').textContent='Rankings currently unavailable; do not use stale results.';}}
async function refreshStatus(){if(!db)return;try{let s=await api('/api/status');let previous=db.status?.refresh?.lastSuccess;db.status=s;showCoverage();let x=s.refresh;if(x.lastSuccess&&x.lastSuccess!==previous){const fresh=await api('/api/bootstrap');db.players=fresh.players;db.defense=fresh.defense;renderBoard();matchup();rankings();}$('syncHealth').textContent=x.active?'Updating':'Data ready';$('refreshState').textContent=x.stage||'Server online';$('statusBar').textContent=x.error?`Live refresh unavailable: ${x.error}. Serving ${s.source} data as of ${s.dataAsOf}.`:`Source: ${s.source}; as of ${s.dataAsOf}. ${x.active?x.stage:'Last valid snapshot retained.'} ${x.stats?.completedGames?`Games validated ${x.stats.usableGames}/${x.stats.completedGames}; rejected ${x.stats.rejectedGames}.`:''}`;$('statusBar').classList.toggle('source-warning',Boolean(x.error))}catch(e){$('syncHealth').textContent='Server unavailable';$('statusBar').textContent=e.message}}
async function matchup(){if(!db)return;let serial=++requestSerial,defense=$('team').value,offense=$('offense').value,id=$('player').value;if(!id)return;
 if(defense===offense){$('qualityNote').textContent='Choose a different defending team. A team cannot play itself.';return}
 const local=profileLocal();renderCourt(local,null);renderGrade(null,local);$('playerLookupStatus').textContent='Checking server for player shot zones…';
 try{let r=await api(`/api/matchup?defense=${defense}&offense=${offense}&playerId=${encodeURIComponent(id)}`);if(serial!==requestSerial)return;
  renderCourt(r.profile||local,r.grade);renderGrade(r.grade,r.profile||local);$('playerLookupStatus').textContent=r.profile?`Loaded ${r.profile.name} (${r.profile.source}) — ${r.profile.gp||'?'} games, ${total(r.profile)} classified attempts.`:'No profile saved yet. Fetching this player’s completed team games from ESPN on the server.';
  if(!r.profile||!String(r.profile.source||'').startsWith('ESPN'))requestPlayer(offense,id,serial);
 }catch(e){$('playerLookupStatus').textContent=`Lookup failed: ${e.message}. Saved defensive data stays visible.`}
}
async function requestPlayer(team,id,serial){if(currentLookup===team+':'+id)return;currentLookup=team+':'+id;
 try{await api('/api/player',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({team,id})});}
 catch(e){if(serial===requestSerial)$('playerLookupStatus').textContent='On-demand lookup could not start: '+e.message;currentLookup=null;return}
 let tries=0;if(lookupTicker)clearInterval(lookupTicker);
 lookupTicker=setInterval(async()=>{tries++;if(serial!==requestSerial||tries>15){clearInterval(lookupTicker);currentLookup=null;return}
 try{const r=await api(`/api/matchup?defense=${$('team').value}&offense=${team}&playerId=${id}`);if(String(r.profile?.source||'').startsWith('ESPN')){
 renderCourt(r.profile,r.grade);renderGrade(r.grade,r.profile);$('playerLookupStatus').textContent=`Updated ${r.profile.name} from ESPN through ${r.profile.asof} (${r.profile.gp} GP). Zone boundaries are estimated.`;clearInterval(lookupTicker);currentLookup=null;rankings();
 }else $('playerLookupStatus').textContent=`Checking shot-zone feed for ${rosterItem()?.name||'player'}… ${tries*5}s elapsed. Saved numbers remain visible.`;
 }catch(e){$('playerLookupStatus').textContent='Player update unavailable: '+e.message;clearInterval(lookupTicker);currentLookup=null}
 },5000);
}
function selectChanged(){if(!db)return; if($('offense').value===$('team').value){$('playerLookupStatus').textContent='Select different teams';return;}renderComparison();matchup();}
async function loadApp(){try{db=await api('/api/bootstrap');selectedDate=db.status.date;fillTeams();
 if(db.schedule?.length){let a=db.schedule[0];$('team').value=a.home;$('offense').value=a.away;}else{$('team').value='CHA';$('offense').value='BOS';}
 fillPlayers(favoredRosterId($('offense').value));showCoverage();renderToday();renderBoard();renderComparison();await matchup();await rankings();refreshStatus();loadSchedule();}
 catch(e){document.querySelector('header .sub').textContent='The app backend is unavailable. Run the Node server, or deploy it to a web host. '+e.message;$('syncHealth').textContent='Offline';$('statusBar').textContent=e.message;}}
async function loadSchedule(force=false){
 const day=selectedDate,serial=++slateRequestSerial;
 try{const d=await api('/api/schedule?date='+encodeURIComponent(day)+(force?'&fresh=1':''));
  if(serial!==slateRequestSerial)return;
  db.schedule=d.schedule||[];renderToday();$('gameSource').textContent=d.cached?'Cached NBA schedule':'ESPN NBA schedule';
  if(d.warning)$('gameSource').textContent+=' · last verified copy';
  if(rankScope==='today')rankings();
 }catch(e){if(serial!==slateRequestSerial)return;
  db.schedule=[];$('gameCount').textContent='Schedule unavailable';$('todayGames').innerHTML='<div class="slate-empty">Could not load the NBA schedule: '+safe(e.message)+'. Try Refresh schedule.</div>';rankings();
 }
}
$('gamePrev').addEventListener('click',()=>moveSlateDay(-1));
$('gameNext').addEventListener('click',()=>moveSlateDay(1));
$('gameDate').addEventListener('change',e=>changeDay(e.target.value));
$('gameToday').addEventListener('click',()=>changeDay(db.status.date));
$('gameReload').addEventListener('click',()=>changeDay(selectedDate,true));
$('team').addEventListener('change',()=>{if($('team').value===$('offense').value){let alt=db.defense.teams.find(t=>t.code!==$('team').value);$('offense').value=alt.code;fillPlayers()}selectChanged()});
$('offense').addEventListener('change',()=>{if($('team').value===$('offense').value){$('team').value=db.defense.teams.find(t=>t.code!==$('offense').value).code}fillPlayers();selectChanged()});
$('player').addEventListener('change',selectChanged);
$('measure').addEventListener('change',()=>renderCourt(profileLocal(),lastGrade));
$('compare').addEventListener('change',renderComparison);
$('loadPlayer').addEventListener('click',()=>{currentLookup=null;requestPlayer($('offense').value,$('player').value,requestSerial)});
$('scopeToday').addEventListener('click',()=>{rankScope='today';$('scopeToday').classList.add('primary');$('scopeAll').classList.remove('primary');rankings()});
$('scopeAll').addEventListener('click',()=>{rankScope='all';$('scopeAll').classList.add('primary');$('scopeToday').classList.remove('primary');rankings()});
$('refresh').addEventListener('click',async()=>{try{let r=await api('/api/refresh',{method:'POST'});$('statusBar').textContent=r.accepted?'Full-season rebuild started on server. Existing snapshot stays available until verification completes.':r.reason;refreshStatus()}catch(e){$('statusBar').textContent=e.message}});
$('reload').addEventListener('click',loadApp);
setInterval(refreshStatus,12000);
loadApp();
