# NBA Scout v3.14 — Reliable daily frozen picks + results

## One ZIP upload, same as before

1. Upload the enclosed NBA_Scout_RELEASE_v3.14.zip as a ZIP (do not extract) to the **root** of the `main` branch of https://github.com/Cosentinoc1/nba-shortzone-scout.
2. Commit the ZIP. The existing **NBA Scout Auto-Update** Action extracts the highest version ZIP, runs all tests, and commits updated source. Render should auto-deploy.
3. Verify GitHub **Actions → NBA Scout Daily Results** appears and that the site `/review.html` includes November 9 as **Not frozen** rather than falsely reporting 0% success.
4. For an initial check, manually run **NBA Scout Daily Results → Run workflow**, with `auto` (capture if before games; grade if run with `grade` and an actual frozen date). You can use `grade` for prior snapshots; `capture` refuses historical dates.

### IMPORTANT WORKFLOW PERMISSION FALLBACK

If Auto-Update fails with an error about updating `.github/workflows/nba-scout-daily-review.yml`, GitHub blocked a workflow file created by the auto-installer's token. In that case, download/unzip the release locally and add the supplied workflow file **manually** at `.github/workflows/nba-scout-daily-review.yml` in the GitHub website; commit it with your account. Then rerun Auto-Update. Do not bypass the tests.

### What changed

- The GitHub repository previously had the capture/audit script but **no daily scheduler**. This release installs the missing schedule.
- Capture runs several times during the day, with a hard stop for already-started games. It freezes the first valid list and never overwrites it with postgame knowledge.
- `public/review/history.json` is committed persistently so Render restarts do not erase records.
- A 503/error produces an explicit **Not frozen** date with a source error, not an empty 0% hit rate.
- It uses ESPN official final NBA box scores for win/loss/push/void and excludes unresolved outcomes from the denominator.
- Adds a truthful November 9 missing-snapshot note. The exact November 9 Top 10 cannot be recovered from a postgame board.
- Browser-only RotoWire files are not available to the unattended GitHub workflow. Scheduled picks are explicitly labeled as research and not final betting recommendations.

### Test commands

`npm test` runs the existing regression suite, plus the new scheduler tests.

### Limitations

GitHub scheduled workflows can run late. Only verified pre-tip observations count. The site must have an accessible, fresh licensed prop feed and NBA game schedule; empty or invalid boards remain visible failure/no-qualified records. This does not guarantee 10 picks or profitability.
