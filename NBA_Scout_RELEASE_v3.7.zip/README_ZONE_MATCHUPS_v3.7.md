# NBA Scout v3.7 — Separate Defensive Zone Grades + Automatic Game Matchups

**Upload `NBA_Scout_RELEASE_v3.7.zip` as-is to the GitHub repository root.** The existing NBA Scout Auto-Update workflow extracts the highest `NBA_Scout_RELEASE_v*.zip`, runs `npm test`, and commits the updated site. This ZIP contains **no `.github/workflows/` files**; it will not attempt to create a protected Actions workflow. The previous RFPP 2.7 Top 10 and Performance Review remain intact.

## New in Defense Zones

1. Select any of the 30 NBA defenses and inspect six court zones.
2. Every zone shows **two distinct 0–100 descriptive grades**: Volume Allowed and FG% Allowed. A score of 50 is league-neutral; higher means more permissive for that component. The volume metric compares the zone's *share of all allowed attempts* with the NBA average, not cumulative FGA counts between teams. FG% grades shrink noisy small samples toward 50.
3. At the top of this tab, **Top player vs. defensive-zone matches for every game** automatically loads from the selected GAME DAY. It ranks current roster players by their own season shot distribution against the opponent's *pre-slate* defensive zone distribution, with recent actual FGA/minutes from ESPN historical box scores.
4. View **All games** (top three per matchup) or pick one game (top ten); sort by overall opportunity match, defensive shot-volume fit, defensive FG% fit, or 3-point-zone alignment. Tap a ranked player to jump to the opponent's corresponding defensive zone on the court.

## Ranking, fairness and safety

- Game match weights: 30% opposing defense's shot-volume overlap, 21% opposing defense's FG% overlap, 22% player's own shots per game, 14% recent actual minutes, 8% recent attempt trend, 5% minute stability. These are **research weights**, not calibrated expected returns or hit probabilities.
- It normalizes opponent volume by **zone share**, avoiding a comparison of raw season attempts from teams with unequal games played.
- Missing minutes remain marked unknown. Fewer than 4 games or 32 classified attempts, less than 3.5 total FGA per game, last-five minutes under 16, missing roster identity or no recent appearances are filtered. Output is allowed to be shorter than 10.
- Each date's modeling history **excludes all games on that date using America/Chicago game dates**, even if ESPN recorded the event under the next UTC day. Historical viewing is descriptive; ranks are not frozen bets and are not guaranteed to have existed live before that game's tip.
- **No lineup, injury, next-game projected minutes, position assignments, live PrizePicks lines, market prices or win probabilities are invented.** The game-specific alignment helps choose whom to investigate; RFPP final veto and verified payout remain necessary before any wager.
- All zones are **ESPN play-by-play coordinate estimates**, not the NBA's official court-zone table.

## Implementation

Additive and idempotent. Existing `PATCH_SCOUT_31.py` runs `PATCH_SCOUT_ZONES_35.py`, which runs the new `PATCH_SCOUT_MATCHUPS_37.py`. The installer preserves the original website, prop grading and saved Performance Review history. New files: `lib/zone-opportunities.mjs`, `public/zone-metrics.mjs`, `public/zone-opportunity-ui.mjs`, plus one six-case test module.

The site serves `GET /api/zone-opportunities?date=YYYY-MM-DD` with read-only player profiles generated from **games before the selected date**, plus two static browser assets. It uses existing ESPN game cache and schedule; no new third-party credentials or external services are required.

## Installation verification

1. GitHub Actions > NBA Scout Auto-Update must be green, with **all** tests passing and the **Commit tested source** step green.
2. Render should redeploy after the install commit.
3. On the live website open **Defense Zones**. The auto-match section should list the selected day's NBA games and players; changing GAME or WHAT TO RANK updates the list. Tap a player to jump to the opponent zone.
4. Confirm a zone shows separate **Volume Allowed Grade** and **FG% Allowed Grade**. The `GET /api/zone-opportunities?date=...` response should include `modelVersion:"zone-fit-1.0"`.
5. `/review.html` and the existing RFPP Top 10 should remain functional. The scheduled daily review is still a **separate optional setup**, and is not automatically enabled by uploading this ZIP.

Developer unit tests: `npm test`. The six new zone-opportunity tests cover separate grades, small-sample shrinkage, game-opponent identity, minutes/roster exclusions, Chicago date boundaries and navigation integration. Before deployment, tests were exercised in a synthetic integration environment and code anchors were checked against the live GitHub repository; the full GitHub workflow is the definitive production integration test.
