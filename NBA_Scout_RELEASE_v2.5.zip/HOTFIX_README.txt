NBA SCOUT RFPP 2.5 -- VERIFIED PATCH FOR WORKFLOW RUN #14

Why run #14 failed: npm test reported 81 passing, 3 failing RotoWire tests.
Those 3 failures shared one TypeError: lib/edge-v3.mjs tried to round a missing
DvP score, because a legacy test/mock claimed available:true without providing
actual exact-position defensive scores. The bug is fixed in this release.

Fixes:
1. Numeric rounding never calls .toFixed() on undefined or other absent data.
2. Exact defensive matchup is only used if the grade has explicitly verified
   position, score and lessScore; otherwise it stays unverified / neutral.
3. Added 3 direct regression checks covering the crash and exact-position grades.
4. Existing pretest applies RFPP 2.1 + 2.2 once and removes itself.
5. Does not include .github/workflows files (prior GitHub write permissions bug).

INSTALL:
Upload the ZIP to the GitHub repository ROOT as NBA_Scout_RELEASE_v2.5.zip.
The existing NBA Scout Auto-Update workflow finds the latest ZIP by version,
extracts it, runs npm test, and commits ONLY if tests succeed.
Render then auto-deploys the source commit. Do NOT manually rerun older jobs.

Target site: https://nba-shotzone-scout.onrender.com/api/status
Expected successful release version: 2.2.0 (2.5 is installer filename).
Only targeted tests have been run locally; GitHub must pass the entire suite.
