NBA SCOUT 2.3 INSTALLER HOTFIX — 2026-11-07

Fixes GitHub Actions run #11 failure: GitHub App cannot push a newly created .github/workflows file.

This ZIP DOES NOT INCLUDE ANY WORKFLOW FILE. Your existing NBA Scout Auto-Update action can handle it:
1. Upload NBA_Scout_RELEASE_v2.3.zip to the ROOT of Cosentinoc1/nba-shortzone-scout.
2. Under GitHub Actions > NBA Scout Auto-Update > Run workflow, choose main and run.
3. Existing workflow extracts the highest version ZIP and runs npm test.
4. The temporary package.json pretest hook applies the RFPP 2.1 + 2.2 patches, then removes itself.
5. All tests run. If they pass, the existing workflow commits the source WITHOUT a new .github/workflows file and Render automatically deploys.
6. Check https://nba-shotzone-scout.onrender.com/api/status for version 2.2.0.

If the workflow fails at tests, don't force a deploy. Send the new log for diagnosis.
