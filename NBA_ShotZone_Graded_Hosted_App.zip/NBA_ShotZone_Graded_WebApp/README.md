# NBA Shot-Zone Scout — Hosted Web App

A Node.js (20+) web dashboard combining six-zone defensive shot charts, current 30-team roster selections, player shot-location profiles, explanatory grades, and Top 6 / Worst 6 matchup screening.

## Start locally

```bash
npm start
```

Open http://localhost:3000. Test with `npm test`.

The app uses only built-in Node APIs; there is no `npm install` dependency required.

## Publish on Render

1. Create a GitHub repository and upload **the contents of this folder** (not the ZIP itself).
2. In Render, choose **New → Blueprint** and select the repository; `render.yaml` defines the service. Alternatively create **New → Web Service** with Node runtime, build command `npm install --omit=dev`, start command `npm start`, and health check `/api/health`.
3. Once deployed, use the `onrender.com` URL from Render. Initial page loads bundled official NBA shot-zone snapshot. The backend fetches today's ESPN schedule and season shot details when ESPN permits access.

## Refresh behavior / reliability

- A server refresh checks ESPN completed 2026-27 games and only promotes a new 30-team dataset after all games pass play-by-play vs box-score FGA validation.
- A player selected on the court triggers server-side ESPN game lookups, retaining saved data if the upstream source blocks access.
- Refresh cadence defaults to 12 hours *while the host process is running*; it is not a guaranteed daily refresh on a sleeping free plan. Click **Refresh season data on server** for a manual attempt.
- `data/cache.json` is generated at runtime. Free-tier ephemeral storage may reset on restart; for persistent refreshes, use a persistent disk, database, or external scheduled worker.
- Game-derived court zones reconstruct NBA zone boundaries from ESPN coordinates and therefore are **approximations**, not official classifications. Data source and cutoff date are shown in the interface.

## Matchup grades

A screening score based on (1) player share of attempts by zone, (2) opposing team zone attempt frequency relative to the league, and (3) opposing team allowed FG% relative to the league. Volume alignment contributes 68%; opponent FG% alignment contributes 32%. Scores are bounded 10–90 and labeled A (65+), B (58+), C (48+), D (40+), F (<40).

Top/Worst 6 require at least 40 total classified attempts and 4 played games. With insufficient coverage or an unavailable current slate, the app displays an **unavailable** state, rather than inventing rankings. Use All team pairings for *hypothetical* non-slate comparisons.

The grade is **not** a win probability, projection, or betting recommendation; it does not verify position-specific defense, projected role/minutes, injuries, prop prices, or sportsbook lines.

## API

- `GET /api/health` and `/api/status` — health/data provenance
- `GET /api/bootstrap` — rosters, defensive zones and saved player profiles
- `GET /api/schedule` — today's NBA games
- `GET /api/matchup?defense=BOS&offense=ATL&playerId=...` — player matchup explanation
- `POST /api/player` with JSON `{"team":"ATL","id":"..."}` — request player refresh
- `GET /api/rankings?scope=today|all` — screened Top/Worst 6
- `POST /api/refresh` — start validated season rebuild (cooldown protection)

Data sources: official NBA opponent/player shooting-by-zone 2026-27 partial Nov 5 snapshot bundled for offline display; ESPN current rosters and live schedule/play-by-play when available. The initial bundle contains all 30 team rosters but only 152 saved shooting profiles.

### Daily game center (v1.1)

The home page lists every game returned for the selected NBA calendar date, with game status, local Central Time tipoff and available final scores. Tap a game or press **Analyze AWAY** or **Analyze HOME** to set the opposing teams, preselect the strongest measured shooter (when saved data exists), and load the six-zone court and grading sections. The date picker and arrows let users select other 2026-27 regular season dates; Top/Worst six rankings follow the selected slate when in “Today's games” scope.

`GET /api/schedule?date=YYYY-MM-DD` and `/api/rankings?scope=today&date=YYYY-MM-DD` are date-aware. ESPN scoreboards are cached for two minutes on the current day and twenty minutes on other days; fresh=1 forces a refresh. If upstream schedule data fails, the server can reuse a previously validated in-process date cache. It will not fabricate games.
