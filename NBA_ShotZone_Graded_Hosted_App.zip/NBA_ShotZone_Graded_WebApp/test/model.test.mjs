import test from 'node:test';
import assert from 'node:assert/strict';
import {coordinateZone,matchupGrade,rankMatchups,parseESPNGame,zeroZones,normalizeTeam} from '../lib/model.mjs';
import {readFileSync} from 'node:fs';
const defense=JSON.parse(readFileSync(new URL('../data/defense.json',import.meta.url)));
const players=JSON.parse(readFileSync(new URL('../data/players.json',import.meta.url)));
test('ESPN team aliases',()=>{assert.equal(normalizeTeam('NO'),'NOP');assert.equal(normalizeTeam('UTAH'),'UTA')});
test('court zone classifier including heaves and free throws',()=>{
 const p=(x,y,pointsAttempted)=>({coordinate:{x,y},pointsAttempted});
 assert.equal(coordinateZone(p(25,2,2)),'rim');
 assert.equal(coordinateZone(p(25,12,2)),'paint');
 assert.equal(coordinateZone(p(24,27,2)),'mid');
 assert.equal(coordinateZone(p(2,7,3)),'left');
 assert.equal(coordinateZone(p(48,7,3)),'right');
 assert.equal(coordinateZone(p(22,24,3)),'above');
 assert.equal(coordinateZone(p(12,47,3)),'heave');
 assert.equal(coordinateZone(p(25,1,1)),null);
});
test('matchup cannot be ranked if player has no shot volume',()=>{
 const d=defense.teams[0],p={name:'Zero attempts',gp:8,zones:zeroZones()};assert.equal(matchupGrade(p,d,defense.league).eligible,false);
});
test('grade is bounded and clearly not a probability',()=>{
 const p=players.find(x=>x.gp>=4&&Object.values(x.zones).reduce((n,z)=>n+z.fga,0)>=40);
 assert.ok(p,'At least one sample player has enough shots');let g=matchupGrade(p,defense.teams[0],defense.league);
 assert.ok(g.score>=10&&g.score<=90);assert.equal(g.rows.length,6);assert.match(g.method,/NOT P\(win\)/);
});
test('rankings only cover requested actual matchup and eligible players',()=>{
 const out=rankMatchups({players,defense,matchups:[{away:'ATL',home:'BOS',label:'ATL @ BOS'}],scope:'today'});
 assert.equal(out.pairings,2);assert.ok(out.top.every(x=>['ATL','BOS'].includes(x.offense)));
 assert.ok(out.top.every(x=>x.games>=4&&x.attempts>=40));
 assert.ok(out.worst.length<=6&&out.top.length<=6);
});
test('play-by-play validation catches incomplete boxscore totals',()=>{
 const fake={boxscore:{teams:[{team:{id:'1',abbreviation:'ATL'},statistics:[{name:'fieldGoalsMade-fieldGoalsAttempted',displayValue:'1-20'}]},{team:{id:'2',abbreviation:'BOS'},statistics:[{name:'fieldGoalsMade-fieldGoalsAttempted',displayValue:'1-20'}]}]},plays:[{shootingPlay:true,team:{id:'1'},participants:[{athlete:{id:'a'}}],pointsAttempted:2,coordinate:{x:25,y:1}}]};
 assert.throws(()=>parseESPNGame({id:1,date:'2026-10-25'},fake),/play-by-play FGA/);
});
