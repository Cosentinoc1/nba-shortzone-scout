import http from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { existsSync, createReadStream } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { aggregateGames, parseESPNGame, matchupGrade, rankMatchups, normalizeTeam, keyName, localDate, ZONES, totalShots } from './lib/model.mjs';
const ROOT=path.dirname(fileURLToPath(import.meta.url));
const snapshotDefense=JSON.parse(await readFile(path.join(ROOT,'data/defense.json'),'utf8'));
const snapshotPlayers=JSON.parse(await readFile(path.join(ROOT,'data/players.json'),'utf8'));
const rosters=JSON.parse(await readFile(path.join(ROOT,'data/rosters.json'),'utf8'));
const BASE='https://site.api.espn.com/apis/site/v2/sports/basketball/nba';
const START='2026-10-20T00:00:00Z';
const CACHE=process.env.CACHE_FILE||path.join(ROOT,'data/cache.json');
const REFRESH_MS=Math.max(1,Number(process.env.AUTO_REFRESH_HOURS)||12)*3600000;
const PORT=Number(process.env.PORT)||3000;
let defense=snapshotDefense,players=snapshotPlayers,source='NBA official snapshot (2026-11-05)',dataAsOf='2026-11-05',schedule=[],scheduleDate=null,scheduleError=null;
let gameCache={},profileCache={},busy=false,refreshStage='',error=null,refreshLast=null,startedAt=new Date().toISOString(),lastAttempt=0;
let rosterNum=Object.values(rosters).reduce((n,x)=>n+x.length,0);
const monthCache=new Map(),lookups=new Set();
try{
 if(existsSync(CACHE)){const d=JSON.parse(await readFile(CACHE,'utf8'));gameCache=d.gameCache||{};profileCache=d.profileCache||{};
 if(d.defense?.teams?.length===30&&d.players?.length>300&&d.source==='ESPN fully validated'){
   defense=d.defense;players=d.players;dataAsOf=d.dataAsOf||dataAsOf;source=d.source;
 }
 }
}catch(e){console.warn('Cache not loaded:',e.message)}
const rosterFor=(code,id)=>rosters[code]?.find(p=>String(p.id)===String(id));
const profileKey=(code,id)=>`${code}:${id}`;
function profileFor(code,id){const r=rosterFor(code,id);if(!r)return null;
 const p=profileCache[profileKey(code,id)]||players.find(x=>x.team===code&&(String(x.id)===String(id)||keyName(x.name)===keyName(r.name)));
 return p?{...p,id:String(id),pos:p.pos||r.pos,name:r.name,team:code,source:p.source||source,asof:p.asof||dataAsOf}:null;
}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function fetchJson(url, timeout=13000, attempts=2){let last;
 for(let i=0;i<attempts;i++){const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),timeout);
  try{const res=await fetch(url,{signal:ctrl.signal,headers:{'Accept':'application/json','User-Agent':'NBA-Zone-Scout/1.0 (+research-dashboard)'}});
   if(!res.ok)throw new Error(`ESPN HTTP ${res.status}`);const body=await res.json();return body;
  }catch(e){last=e;if(i+1<attempts)await sleep(600*(i+1))}finally{clearTimeout(timer)}
 }
 throw new Error(`${url.split('?')[0]}: ${last?.message||'Unknown error'}`);
}
function monthsThroughNow(){let end=localDate().replaceAll('-','').slice(0,6),y=2026,m=10,out=[];for(let k=0;k<18;k++){let s=String(y)+String(m).padStart(2,'0');if(s>end)break;out.push(s);m++;if(m===13){m=1;y++}}return out}
async function seasonEvents(){let events=[];
 for(const mo of monthsThroughNow()){
  const cache=monthCache.get(mo);const ttl=mo===localDate().replaceAll('-','').slice(0,6)?900000:86400000;
  let obj;if(cache&&Date.now()-cache.time<ttl)obj=cache.data;
  else {obj=await fetchJson(`${BASE}/scoreboard?dates=${mo}&limit=500`,18000);monthCache.set(mo,{data:obj,time:Date.now()})}
  events.push(...(obj.events||[]).filter(e=>e.season?.type===2&&e.status?.type?.completed===true&&Date.parse(e.date)>=Date.parse(START)));
 }
 return [...new Map(events.map(e=>[String(e.id),e])).values()].sort((a,b)=>a.date.localeCompare(b.date));
}
async function getSchedule(force=false){const today=localDate();if(!force&&scheduleDate===today)return schedule;
 const val=await fetchJson(`${BASE}/scoreboard?dates=${today.replaceAll('-','')}&limit=50`,12000);
 const matches=(val.events||[]).filter(e=>e.season?.type===2).map(e=>{
  let c=e.competitions?.[0]?.competitors||[],away=normalizeTeam(c.find(x=>x.homeAway==='away')?.team?.abbreviation),home=normalizeTeam(c.find(x=>x.homeAway==='home')?.team?.abbreviation);
  return {id:String(e.id),away,home,label:`${away} @ ${home}`,tipoff:e.date,state:e.status?.type?.state||'pre',completed:Boolean(e.status?.type?.completed)};
 }).filter(g=>rosters[g.away]&&rosters[g.home]);
 schedule=matches;scheduleDate=today;scheduleError=null;return schedule;
}
async function saveCache(){try{await mkdir(path.dirname(CACHE),{recursive:true});await writeFile(CACHE,JSON.stringify({gameCache,profileCache,defense,players,dataAsOf,source}),'utf8')}catch(e){console.warn('Cache write failed:',e.message)}}
async function fetchGames(events,progress){const todo=events.filter(e=>!gameCache[String(e.id)]);let i=0,completed=0,failed=[];
 await Promise.all(Array.from({length:Math.min(4,todo.length)},async()=>{
   while(i<todo.length){const ev=todo[i++];try{const response=await fetchJson(`${BASE}/summary?event=${encodeURIComponent(ev.id)}`,14000);gameCache[String(ev.id)]=parseESPNGame(ev,response)}catch(e){failed.push(`${ev.id}: ${e.message}`)}
   completed++;if(progress)progress(completed,todo.length);
   }
 }));await saveCache();return {failed,requested:todo.length};
}
async function lookupPlayer(team,id){const k=profileKey(team,id),r=rosterFor(team,id);if(!r)throw new Error('Player not on selected roster');if(lookups.has(k))return;
 lookups.add(k);try{
  const events=(await seasonEvents()).filter(e=>(e.competitions?.[0]?.competitors||[]).some(c=>normalizeTeam(c.team?.abbreviation)===team));
  if(!events.length)throw new Error('No completed games found for selected team');
  const {failed}=await fetchGames(events);if(failed.length)throw new Error(`${failed.length} games failed verification; example ${failed[0]}`);
  const zs=Object.fromEntries(ZONES.map(z=>[z,{fgm:0,fga:0}]));let gp=0,latest='';
  for(const ev of events){let game=gameCache[ev.id];let p=game.players.find(p=>p.id===id&&(p.team===team))||game.players.find(p=>p.team===team&&keyName(p.name)===keyName(r.name));if(!p)continue;
    if(p.played||totalShots(p)>0)gp++;
    for(const z of ZONES){zs[z].fga+=p.zones[z]?.fga||0;zs[z].fgm+=p.zones[z]?.fgm||0}if(ev.date>latest)latest=ev.date;
  }
  const total=ZONES.reduce((n,z)=>n+zs[z].fga,0);if(!gp||!total)throw new Error('No qualifying shots recorded for this player');
  profileCache[k]={id,name:r.name,team,pos:r.pos||'',gp,zones:zs,source:'ESPN coordinate estimate',asof:latest.slice(0,10)};
  error=null;await saveCache();
 }catch(e){error=`${r.name} lookup: ${e.message}`;console.warn(error)}finally{lookups.delete(k)}
}
async function fullRefresh(){if(busy)return;busy=true;lastAttempt=Date.now();error=null;refreshStage='Fetching regular-season schedule';
 try{const ev=await seasonEvents();if(ev.length<20)throw new Error(`Only ${ev.length} completed games found`);
   refreshStage=`Checking ${ev.length} completed games`;
   const {failed}=await fetchGames(ev,(done,total)=>{refreshStage=`Validating games ${done}/${total}`});
   if(failed.length)throw new Error(`Only partially downloaded (${failed.length} failed). First: ${failed[0]}`);
   let out=aggregateGames(ev.map(e=>gameCache[e.id]));if(out.defense.teams.length!==30||new Set(out.players.map(x=>x.team)).size!==30)throw new Error('30-team integrity check failed');
   if(!out.players.length||out.players.length<250)throw new Error('Incomplete player set');
   const idsByName=new Map(Object.entries(rosters).flatMap(([team,arr])=>arr.map(x=>[team+':'+keyName(x.name),x])));
   players=out.players.map(p=>{const r=idsByName.get(p.team+':'+keyName(p.name));return {...p,id:r?.id||p.id,name:r?.name||p.name,pos:r?.pos||p.pos,source:'ESPN coordinate estimate',asof:out.asof?.slice(0,10)}});
   defense=out.defense;source='ESPN fully validated';dataAsOf=out.asof?.slice(0,10)||localDate();refreshLast=new Date().toISOString();refreshStage=`Updated ${players.length} player profiles from ${ev.length} games`;await saveCache();
 }catch(e){error=e.message;refreshStage='Retained validated snapshot';console.warn('Refresh:',e.message)}finally{busy=false}
}
function status(){return {serving:true,startedAt,date:localDate(),source,dataAsOf,playerProfiles:players.length,espnProfiles:Object.keys(profileCache).length,rosters:Object.keys(rosters).length,rosterPlayers:rosterNum,scheduleDate,scheduleGames:schedule.length,scheduleError,refresh:{active:busy,stage:refreshStage,lastSuccess:refreshLast,error},onDemandLookups:lookups.size,officialZonesAreExact:source!=='ESPN fully validated'}}
function json(res,obj,statusCode=200){res.writeHead(statusCode,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(obj))}
function requireTeam(code){const t=normalizeTeam(code);return rosters[t]?t:null}
async function handler(req,res){
 const u=new URL(req.url,`http://${req.headers.host||'localhost'}`),pathname=u.pathname;
 try{
  if(pathname==='/api/health')return json(res,{ok:true,source,date:localDate()});
  if(pathname==='/api/status')return json(res,status());
  if(pathname==='/api/bootstrap')return json(res,{defense,players,rosters,schedule,status:status()});
  if(pathname==='/api/schedule'){
   try{await getSchedule(Boolean(u.searchParams.get('fresh')))}catch(e){scheduleError=e.message;return json(res,{schedule,error:e.message,date:localDate(),cached:scheduleDate!==null},503)}
   return json(res,{schedule,date:scheduleDate,source:'ESPN scoreboard'});
  }
  if(pathname==='/api/matchup'){
   let team=requireTeam(u.searchParams.get('defense')),offense=requireTeam(u.searchParams.get('offense')),id=u.searchParams.get('playerId');
   if(!team||!offense||team===offense||!id)return json(res,{error:'Select two distinct valid teams and a player ID'},400);
   const profile=profileFor(offense,id),def=defense.teams.find(x=>x.code===team);if(!rosterFor(offense,id))return json(res,{error:'Player not on offense roster'},404);
   if(!profile)return json(res,{profile:null,grade:null,state:lookups.has(profileKey(offense,id))?'loading':'unavailable',source:status()});
   return json(res,{profile,grade:matchupGrade(profile,def,defense.league),defense:def,league:defense.league,source:status()});
  }
  if(pathname==='/api/player'&&req.method==='POST'){
   let body='';for await(const c of req){body+=c;if(body.length>5000)return json(res,{error:'Payload too large'},413)}
   let a={};try{a=JSON.parse(body)}catch{return json(res,{error:'Invalid JSON'},400)};
   let t=requireTeam(a.team),id=String(a.id||'');if(!t||!rosterFor(t,id))return json(res,{error:'Unknown team/player'},400);
   const k=profileKey(t,id);const cached=profileFor(t,id);if(!lookups.has(k))lookupPlayer(t,id).catch(e=>console.warn(e.message));
   return json(res,{accepted:true,cached:Boolean(cached),loading:true,profile:cached});
  }
  if(pathname==='/api/rankings'){
   const scope=u.searchParams.get('scope')==='all'?'all':'today';const enriched=[...players];
   for(const p of Object.values(profileCache)){const j=enriched.findIndex(x=>x.team===p.team&&keyName(x.name)===keyName(p.name));if(j>=0)enriched[j]=p;else enriched.push(p)}
   const ranked=rankMatchups({players:enriched,defense,matchups:schedule,scope});
   return json(res,{...ranked,asof:dataAsOf,source,day:localDate(),scheduleAvailable:scheduleDate===localDate(),scheduleCount:schedule.length,coverage:{profiles:enriched.length,rosterPlayers:rosterNum}});
  }
  if(pathname==='/api/refresh'&&req.method==='POST'){
   if(busy)return json(res,{accepted:false,reason:'Refresh already running',status:status()},202);
   if(Date.now()-lastAttempt<600000)return json(res,{accepted:false,reason:'Refresh cooldown: 10 minutes',status:status()},429);
   fullRefresh().catch(e=>console.warn(e));return json(res,{accepted:true,status:status()},202);
  }
  if(req.method!=='GET')return json(res,{error:'Method not allowed'},405);
  const files={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/styles.css':'styles.css'};
  const name=files[pathname];if(!name)return json(res,{error:'Not found'},404);
  const dest=path.join(ROOT,'public',name);if(!existsSync(dest))return json(res,{error:'Not found'},404);
  const type=name.endsWith('.html')?'text/html; charset=utf-8':name.endsWith('.css')?'text/css; charset=utf-8':'text/javascript; charset=utf-8';
  res.writeHead(200,{'Content-Type':type,'Cache-Control':name==='index.html'?'no-cache':'public, max-age=300','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY'});createReadStream(dest).pipe(res);
 }catch(e){console.error('Server error',e);json(res,{error:'Server error',detail:e.message},500)}
}
const server=http.createServer(handler);server.listen(PORT,'0.0.0.0',()=>console.log(`NBA Shot Zone Scout on :${PORT}`));
getSchedule().catch(e=>{scheduleError=e.message;console.warn('Schedule:',e.message)});
setInterval(()=>{getSchedule(true).catch(e=>{scheduleError=e.message});fullRefresh().catch(e=>console.warn(e))},REFRESH_MS).unref();
