# NBA Scout v3.16 — Top 2 / Top 5, explainable matchup selection, and research verification

**Upload only `NBA_Scout_RELEASE_v3.16.zip` to the root of `main` at** https://github.com/Cosentinoc1/nba-shortzone-scout — **do not extract it.** GitHub's existing `NBA Scout Auto-Update` workflow detects the highest-numbered release ZIP, extracts it, runs `npm test`, commits changes and triggers Render deploy. **Do not upload a new `.github/workflows` file**: that caused the v3.14 permissions error. The existing Daily Results workflow installed with v3.15 is preserved.

## Added to the main Top 10 page

The **Best 2 / Best 5 of the day** module appears ABOVE the old Top 10. Switching the selector shows either view without rerunning the board. Each pick has the exact standard line/direction, descriptive data-grade, date-specific opponent matchup, historical game log, last-20 clearance if available, recent shot/assist/rebound team rank proxy, playstyle/attempts, injury and projected-minutes context, top three failure modes, remaining final vetoes and a click-through to the entire report. The sample size may be fewer than 2 or 5. No unsupported pick is added to fill a quota.

**New real source-based opportunity context:** the site's cached ESPN completed pregame team box scores are used to calculate the player's average FGA/3PA/FTA, plus his team rank/share of observed field-goal attempts, credited assists or rebounds over the last five prior team games. That is a descriptive **proxy**, not licensed on-court usage percentage, potential assists, rebound chances, or an independent role forecast. It is explicitly labeled as such. The cutoff is America/Chicago local and prevents same-slate results from feeding a pregame ranking. Combined with the existing six-signal RFPP 2.7 process, this supplies actual playing-style detail rather than a generic grade.

**The top-page Source Coverage inspector** reports all-slate data health: line freshness, game history, exact DvP, injuries, news, starters, RotoWire matching, game spread, prices and tracking. **Data checks always show their state:** exact platform line/freshness, L10/L20 box scores, offensive opportunity share, stat/position-specific DvP + estimated zones, ESPN injury feed, licensed starter status (if configured), user-uploaded RotoWire projections, sportsbook quotes and payout, spread/game environment, and unavailable advanced on/off or tracking. Unknown is always labeled MISSING, never silently marked verified.

## What was learned from the supplied YouTube videos

- [Linemaker Sports — The NBA Parlay Strategy Nobody Is Using](https://youtu.be/2dEGauXhljY): start with player role and top usage, opposing position fantasy DvP, minutes x production per minute, and check whether points, rebounds and assists are actually supported. We adopt **context, matchup and volume**, but **do not** multiply independent hit rates or claim a 90% SGP rate: same-player stats are correlated, hit-rate windows are not calibrated probabilities, and bookmaker correlation pricing is necessary.
- [Linemaker Media — I Made $5k in 30 Days Using This NBA Betting Strategy](https://youtu.be/G7OEWTwCQgA): shortlist top-two usage players facing poor position defense, then compare alternate PRA and sportsbook odds. We add **top-two team offensive involvement proxy** and display sourced position-specific DvP, but do **not** assume a box-score FGA ranking equals true usage%, assume the bottom-five matchup automatically creates an edge, or price sportsbook **alternate lines** as PrizePicks **standard lines**. Their past performance assertions are not independently established.
- Additional process principles: prioritize opportunities (expected minutes, FGA/3PA/FTA or tracking chances when present), matchup quality and source freshness before recent stat results. Do not treat L10 clearance percentages as predicted P(win), and veto conflicting independent projections and opponent-zone evidence.

## Postgame tracking

The existing scheduled workflow saves the first genuine pregame Top 10 as before, and now also freezes the contemporaneous Best 2 and Best 5 **separately**. The next official ESPN box-score audit compares the featured props with exact observed lines, not hindsight alternatives, and shows their results under the day in Performance Review. **Featured rows never double-count in the older Top 10 hit rate.** A source outage/no-qualified day remains explicitly ungraded. RotoWire imports remain **private to the browser**; the automatic pregame capture will not include local-only projections.

## Source coverage / unavoidable pending items

Already automated when reachable: independent configured standard-line feed (ParlayAPI/PrizePicks), ESPN NBA final box scores and game context, ESPN injuries/news, NBA House 2026–27 position-specific DvP, ESPN estimated six-zone shot profile, and licensed projected lineups only if an authorized URL is configured. Independently supplied: RotoWire daily projections uploaded through the website. Manual unless you provide an authorized paid source: RotoGrinders actual USG% / projection, same-line sportsbook odds, platform multipliers, confirmed active game-day lineup, NBA tracking potential assists, rebound chances, on/off possessions. **Linking to a provider is not a live integration.** Unknown checks remain pending; no false 'LOCK' or fabricated EV/probability is displayed.

## Verification

The package includes `test/featured-picks-v316.test.mjs`, `test/offense-context-v316.test.mjs`, and `test/featured-review-v316.test.mjs`. GitHub's `npm test` is the integration gate. Confirm GitHub Actions success and `/api/status` returns version `3.16.0`; check `/api/picks?date=YYYY-MM-DD` for a `featuredPicks` object, then open the homepage.

No new GitHub workflow, external API key or subscriber credential is required to install this package. Model performance must be evaluated over multiple frozen, actual slates before treating a score as predictive. No guaranteed bets.
