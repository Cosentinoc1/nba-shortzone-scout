NBA SCOUT RFPP 2.2 — ADDITIONAL EVIDENCE & LIVE POSITIONAL DVP
================================================================
Site: https://nba-shotzone-scout.onrender.com
Repo: https://github.com/Cosentinoc1/nba-shortzone-scout

WHAT IS NEW
-----------
1. PUBLIC EXACT-POSITION DEFENSE: Server attempts to load the 30-team,
   five-position (PG/SG/SF/PF/C) points, rebounds, assists and threes
   tables from publicly accessible NBA House at most once every six hours.
   Stat + position + opposite MORE/LESS direction determine score.
   IMPORTANT: NBA House rank #1 is MOST allowed, #30 LEAST allowed.
   Public DvP data is current season-to-date, not an individual player
   projection; early samples are noisy. ESPN source G/F/C proxy is still
   available but cannot masquerade as verified exact-position A-F.
   RotoWire's user-imported 'Pos' supplies explicit current positions;
   expected lineups can supply them if the authorized source is connected.
   Without an exact position, display unavailable rather than guessing.
   Failures/stale public source remain visible, not backfilled fictionally.

2. EXPANDED EVIDENCE SCORE: Keeps RFPP 2.1's baseline and RotoWire comparison;
   adds last-10 median, actual stat volatility, missed-tail caution,
   non-overlapping current-five vs prior-five per-36 FGA/3PA/FTA,
   points/rebounds/assists component agreement for combo props,
   historical minute stability, required per-36 at RotoWire projected minutes,
   small-sample H2H, back-to-back, blowout spread and market game-total context.
   Caps overlapping tweaks and keeps scores UNCALIBRATED, never hit odds/EV.

3. BETTER SHOPPING EXPERIENCE: Grade Board can filter Promising Only,
   Historical + RotoWire Agree, and Exact DvP Available. Clicking a prop
   opens the upgraded evidence breakdown (stat variance, median,
   normalized margin, DvP source link and timing, opportunities and risks).

4. STILL MISSING IF THE SOURCE CANNOT PROVIDE IT: Confirmed lineups,
   true rebound chances, potential assists, NBA tracking touches/on-off,
   full licensed sportsbook prop odds, payout/EV, and final second-pass veto.
   These stay OPEN/PENDING rather than silently defaulted to pass.

HOW TO INSTALL
--------------
A. This ZIP is a *source upgrade*, not a one-click software installer.
   Extract all contents to matching relative paths at the ROOT of your existing
   GitHub repository (do not put the files in an extra nested directory).
   If your existing GitHub Auto-Update workflow explicitly unpacks uploaded
   release ZIPs, you may upload this ZIP to the repository root instead.
   Simply uploading a ZIP without an unpacking workflow will NOT deploy it.
B. Go to GitHub -> Actions -> 'Apply RFPP 2.2 expanded grading' ->
   'Run workflow' on branch main.
   This runs both the v2.1 compatibility patch and v2.2 changes, checks JS,
   runs npm test, and commits only if all checks pass.
C. On Render, GitHub main should auto-deploy your `nba-shotzone-scout`
   service. Visit /api/status (version should be 2.2.0) then refresh site.
D. Upload the current day's RotoWire XLSX to unlock exact player positions,
   projected minutes and model/history agreement. No subscription credentials
   are stored by this patch. Refresh prop lines as normal.

SAFETY AND VALIDATION
---------------------
- Core scoring modules were unit-tested locally using synthetic examples.
- Full repository npm test will run when the workflow applies the patch.
- Public DvP fetches are best-effort and intentionally not scraped from
  subscription pages. Current-day DvP never enters historical-day backtests.
- No model or historical baseline can guarantee hitting a prop, and score
  does NOT represent a probability or financial value.

CONNECTOR STATUS
----------------
The connected GitHub integration returned 403 on writing this repository.
Therefore ChatGPT cannot truthfully claim the live site is already changed.
