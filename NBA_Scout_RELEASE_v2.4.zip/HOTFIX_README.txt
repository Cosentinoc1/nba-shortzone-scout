NBA SCOUT v2.4 INSTALLER CORRECTION — November 7, 2026

Correction for NBA Scout Auto-Update run #13:
- Run #13 failed during Python pretest at UPGRADE_RFPP_2_2.py line 22.
- The script expected two spaces before the lib/context.mjs cache line, but the
  deployed repository has only ONE. The v2.4 patch now matches the real source.
- Keeps existing Auto-Update install-v14.yml workflow; does not add or modify
  any .github/workflows file (no privileged Workflow write permission required).
- Includes RFPP 2.2 expanded scoring modules, 2.1 foundation and tests.
- No application source should be committed unless all npm tests pass.

STEPS:
1. Upload NBA_Scout_RELEASE_v2.4.zip to the ROOT of your existing GitHub repo.
2. GitHub Actions > NBA Scout Auto-Update: push will trigger it automatically,
   or manually choose Run workflow > main ONCE.
3. A green run means the installer patched source and npm tests passed.
4. Check https://nba-shotzone-scout.onrender.com/api/status after deploy;
   expected "version":"2.2.0".

This zip is the code release, not the built web app. Node 24/Ubuntu warnings
are not the reason run #13 failed; the Python anchor mismatch is.
